/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package net.flowas.template.mock.persistence;

import java.io.InputStream;
import java.lang.reflect.Method;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.JUnitCore;
import org.junit.runner.RunWith;
import org.powermock.api.easymock.PowerMock;
import org.powermock.core.classloader.annotations.PowerMockIgnore;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

/**
 * 
 * @author Administrator
 */
@RunWith(PowerMockRunner.class)
@PrepareForTest({ Persistence.class })
@PowerMockIgnore("javax.management.*")
public class EntityMockTest {

	@Before
	public void setUp() {
		//PowerMock.mockStaticPartial(Persistence.class, "createEntityManagerFactory", String.class);
//	 	PowerMockito.mockStatic(Persistence.class);
//		EntityManagerFactory emf = Persistence.createEntityManagerFactory("fortest", null);
//		PowerMockito
//				.when(Persistence.createEntityManagerFactory(Mockito
//						.anyString()))
//				.thenReturn(emf);
		//EntityManagerFactory emfSpy = Persistence.createEntityManagerFactory("fortest");
		//EntityManagerFactory spy = PowerMockito.spy(emfSpy);
		
		 Method method = PowerMock.method(Persistence.class,
		 "createEntityManagerFactory", String.class);
		 Method expectedMethod = PowerMock.method(DataInitializer.class,
		 "createEntityManagerFactory", String.class);
		 PowerMock.replace(method).with(expectedMethod);
		 PowerMock.replayAll();
		 InputStream in = this.getClass().getResourceAsStream("/data.xml");
		 DataInitializer.insert(in);		
	}

	@After
	public void tearDown() {
	}

	/**
	 * Test of insert method, of class DataInitializer.
	 */
	@Test
	public void testInsert() {
		System.out.println("insert");
		EntityManagerFactory emf = Persistence
				.createEntityManagerFactory("ggfortest");
		EntityManager em = emf.createEntityManager();
		List list = em.createQuery("select u from User as u").getResultList();
		System.out.println("==========" + list.size());
		// TODO review the generated test code and remove the default call to
		// fail.
		// fail("The test case is a prototype.");
	}

	public static void main(String[] args) {
		JUnitCore.runClasses(EntityMockTest.class);
	}
}