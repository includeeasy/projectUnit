package net.flowas.template.mock.persistence;

import java.io.InputStream;

public class Ted {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		InputStream in =Ted.class.getResourceAsStream("/data.xml");        
        System.out.println(in);
		DataInitializer.insert(in);

	}

}
