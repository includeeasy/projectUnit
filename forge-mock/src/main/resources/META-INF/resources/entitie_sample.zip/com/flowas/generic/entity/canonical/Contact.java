package com.flowas.generic.entity.canonical;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.validation.constraints.Size;

import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.roo.addon.entity.RooEntity;
import org.springframework.roo.addon.javabean.RooJavaBean;
import org.springframework.roo.addon.tostring.RooToString;
@Entity
@RooEntity
@RooJavaBean
@RooToString
@Table(name = "basic_contact")
public class Contact implements Serializable{
	@Id
    @GeneratedValue(strategy = GenerationType.AUTO)
	Long id;	
	private String name;	
	private Integer telephone;	
	private String qq;	
	private String email;	
	private String title;	
	@Size(max=2048)
	private String info;
	@Column(name="createDate")	
        @Temporal(javax.persistence.TemporalType.DATE)
        @DateTimeFormat(style = "S-")
	private Date date=new Date();
	public Contact(){}
	public Contact(String isbn, String title, Integer price) {
		this.name = isbn;
		this.title = title;
		this.telephone = price;
	}
	 public Long getId() {    
	        return this.id;        
	    }    
	    
	    public void setId(Long id) {    
	        this.id = id;        
	    }  
}
