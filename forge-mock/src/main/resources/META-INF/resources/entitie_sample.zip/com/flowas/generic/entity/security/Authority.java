package com.flowas.generic.entity.security;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

import com.flowas.generic.entity.AbstractIdEntity;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
//import javax.validation.constraints.NotNull;

import org.springframework.roo.addon.entity.RooEntity;
import org.springframework.roo.addon.javabean.RooJavaBean;
import org.springframework.roo.addon.tostring.RooToString;

//import org.apache.commons.lang.builder.ToStringBuilder;
//import org.hibernate.annotations.Cache;
//import org.hibernate.annotations.CacheConcurrencyStrategy;
/**
 * 权限.
 * 
 * 注释见{@link User}.
 * 
 * @author calvin
 */
@Entity
@RooEntity
@RooJavaBean
@RooToString
@Table(name = "SS_AUTHORITY")
//@Cache(usage = CacheConcurrencyStrategy.NONSTRICT_READ_WRITE)
public class Authority extends AbstractIdEntity {

    @NotNull
    @Size(min = 1, message = "{validator.notEmpty}")
    @Column(nullable = false, unique = true)
    private String name;
    //@NotNull
    @Size(min = 1, message = "{validator.notEmpty}")
    private String displayName;
}
