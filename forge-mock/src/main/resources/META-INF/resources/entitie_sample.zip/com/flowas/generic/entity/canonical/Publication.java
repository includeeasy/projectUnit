/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.flowas.generic.entity.canonical;

import com.flowas.generic.entity.AbstractIdEntity;
import java.util.ArrayList;
import java.util.List;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.OneToMany;
import javax.persistence.OrderBy;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import org.springframework.roo.addon.entity.RooEntity;
import org.springframework.roo.addon.javabean.RooJavaBean;
import org.springframework.roo.addon.tostring.RooToString;

/**
 *
 * @author Administrator
 */
@Entity
@RooEntity
@RooJavaBean
@RooToString
public class Publication extends AbstractIdEntity {    
    @NotNull
    private String title;
    @Column(length = 511)
    private String hierarchicalStructure;
    @Column(length = 16384)
    @NotNull
    @Size(max=2048)
    private String context;
    @OrderBy("id")
    @OneToMany(mappedBy = "publication",cascade = CascadeType.ALL)
    private List<Document> docs = new ArrayList<Document>();   
    
}
