package com.flowas.generic.entity.security;


import com.flowas.generic.entity.AbstractIdEntity;
//import com.flowas.generic.validation.constraints.Email;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.OrderBy;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import org.springframework.roo.addon.entity.RooEntity;
import org.springframework.roo.addon.javabean.RooJavaBean;
import org.springframework.roo.addon.tostring.RooToString;



/**
 * 用户.
 * 
 * 使用JPA annotation定义ORM关系.
 * 使用Hibernate annotation定义JPA 1.0未覆盖的部分.
 * 
 * @author calvin
 */
@Entity
@RooEntity
@RooJavaBean
@RooToString
//表名与类名不相同时重新定义表名.
@Table(name = "SS_USER")
//默认的缓存策略.
//@DiscriminatorValue("user")
public class User extends AbstractIdEntity {
//字段非空且唯一,用于提醒Entity使用者及生成DDL.
	@NotNull
    @Size(min = 1, message = "{validator.notEmpty}")
        @Column(nullable = false, unique = true)
	private String loginName;
        @NotNull
    @Size(min = 1, message = "{validator.notEmpty}")
	private String password; //为简化演示,使用明文保存密码.
	private String name;
    //    @Email
	private String email;
        //private boolean banned;
	//多对多定义 .         
	@ManyToMany
	//中间表定义,表名采用默认命名规则
	@JoinTable(name = "SS_USER_ROLE", joinColumns = { @JoinColumn(name = "USER_ID") }, inverseJoinColumns = { @JoinColumn(name = "ROLE_ID") })
	//集合按id排序.
	@OrderBy("id")	
	private List<Role> roleList = new ArrayList<Role>(); //有序的关联对象集合.
	
}