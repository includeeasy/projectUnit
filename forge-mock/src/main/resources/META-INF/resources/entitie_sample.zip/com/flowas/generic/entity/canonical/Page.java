/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package com.flowas.generic.entity.canonical;

import com.flowas.generic.entity.AbstractIdEntity;
import java.util.ArrayList;
import java.util.List;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.validation.constraints.Size;

import org.springframework.roo.addon.entity.RooEntity;
import org.springframework.roo.addon.javabean.RooJavaBean;
import org.springframework.roo.addon.tostring.RooToString;

/**
 *
 * @author Administrator
 */
@Entity
@RooEntity
@RooJavaBean
@RooToString
public class Page  extends AbstractIdEntity {
    private int number;//页码
    @ManyToOne(cascade = CascadeType.MERGE)
    private Document document;
    private String title;    
    @Size(max=2048)
    private String context;
    @OneToMany(mappedBy = "page")
    private List<Note> notes=new ArrayList<Note>();    
}
