package com.flowas.generic.entity.canonical;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OrderBy;
import javax.persistence.Temporal;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.roo.addon.entity.RooEntity;
import org.springframework.roo.addon.javabean.RooJavaBean;
import org.springframework.roo.addon.tostring.RooToString;

import com.flowas.generic.entity.AbstractIdEntity;

@Entity
@RooEntity
@RooJavaBean
@RooToString
public class Comment extends AbstractIdEntity{
    @Column(name = "title", length = 255, nullable = true)
    private String title;    
	@NotNull
    @Size(max=2048)
    protected String contex;
    @Temporal(javax.persistence.TemporalType.DATE)
    @DateTimeFormat(style = "S-")
    protected Date publishedDate;
    @Temporal(javax.persistence.TemporalType.DATE)
    @DateTimeFormat(style = "S-")
    protected Date lastReplyDate;
    @Column(name = "DISABLED", nullable = false)
    protected boolean disabled = false;
    /*
    @RooPlural("users")
    @ManyToOne(fetch = FetchType.LAZY)
    protected Account user;
     */   
    @ManyToOne
    private Document document;
    @ManyToOne
    @JoinColumn(name = "PARENT_ID")
    protected Comment parent;
    @OneToMany(fetch = FetchType.LAZY)
    @JoinColumn(name = "PARENT_ID")
    @OrderBy("id")
    protected List<Comment> children = new ArrayList<Comment>();
    @ManyToOne
    @JoinColumn(name = "ROOT_ID")
    protected Comment root;
}
