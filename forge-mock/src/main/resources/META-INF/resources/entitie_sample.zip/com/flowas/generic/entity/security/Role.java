package com.flowas.generic.entity.security;


import com.flowas.generic.entity.AbstractIdEntity;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.OrderBy;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import org.springframework.roo.addon.entity.RooEntity;
import org.springframework.roo.addon.javabean.RooJavaBean;
import org.springframework.roo.addon.tostring.RooToString;

/**
 * 角色.
 * 
 * 注释见{@link User}.
 * 
 * @author calvin
 */
@Entity
@RooEntity
@RooJavaBean
@RooToString
@Table(name = "SS_ROLE")
public class Role extends AbstractIdEntity{
@NotNull
    @Size(min = 1, message = "{validator.notEmpty}")
	@Column(nullable = false, unique = true)
	private String name;
    @ManyToMany
	@JoinTable(name = "SS_ROLE_AUTHORITY", joinColumns = { @JoinColumn(name = "ROLE_ID") }, inverseJoinColumns = { @JoinColumn(name = "AUTHORITY_ID") })
	@OrderBy("id")
	private List<Authority> authorityList = new ArrayList<Authority>();      
	
}
