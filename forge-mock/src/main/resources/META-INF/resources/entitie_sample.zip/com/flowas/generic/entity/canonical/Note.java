package com.flowas.generic.entity.canonical;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.validation.constraints.Size;

import org.springframework.roo.addon.entity.RooEntity;
import org.springframework.roo.addon.javabean.RooJavaBean;
import org.springframework.roo.addon.tostring.RooToString;

@Entity
@RooEntity
@RooJavaBean
@RooToString
@Table(name = "novel_note")
public class Note implements java.io.Serializable {
    @ManyToOne
    private Page page;

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "idNo")
    private Long id;
    private String title;
    @Size(max=2048)
    private String context;
    private String position;
    private String other;
    public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	} 
}
