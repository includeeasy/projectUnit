/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.flowas.generic.entity.canonical;

import com.flowas.generic.entity.AbstractIdEntity;
import com.flowas.generic.entity.security.User;
import java.util.ArrayList;
import java.util.List;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OrderBy;
import javax.persistence.Table;
import javax.validation.constraints.Size;

import org.springframework.roo.addon.entity.RooEntity;
import org.springframework.roo.addon.javabean.RooJavaBean;
import org.springframework.roo.addon.plural.RooPlural;
import org.springframework.roo.addon.tostring.RooToString;
/**
 *
 * @author Administrator
 */
@Entity
@RooEntity
@RooJavaBean
@RooToString
@Table(name = "basic_document")
public class Document extends AbstractIdEntity {
    @OneToMany(mappedBy = "document")
    private List<Comment> comments=new ArrayList<Comment>();
    @ManyToOne(cascade ={ CascadeType.MERGE})
    private Publication publication;

    @ManyToOne
    @RooPlural("authers")
    private  User  creater;

    private String title;
    @Column(length = 16384)
    @Size(max=2048)
    private String context;
    @OrderBy("number")
    @OneToMany(mappedBy = "document",cascade=CascadeType.ALL)
    private List<Page> pages =new ArrayList<Page>();    
}
