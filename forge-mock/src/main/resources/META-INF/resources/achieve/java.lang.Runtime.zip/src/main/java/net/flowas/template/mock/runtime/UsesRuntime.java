package net.flowas.template.mock.runtime;

import java.io.InputStream;

public class UsesRuntime {
	public void run() throws Exception {
		Runtime rt = Runtime.getRuntime();
		Process p = rt.exec("notepad");
		InputStream in = p.getInputStream();
		byte[] b = new byte[in.available()];
		in.read(b);
		System.out.println("standInfo:" + new String(b));
	}
}
