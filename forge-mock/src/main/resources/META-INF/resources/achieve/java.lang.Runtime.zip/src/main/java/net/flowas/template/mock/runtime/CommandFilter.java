package net.flowas.template.mock.runtime;

public interface CommandFilter {
  String[] exec(String command);
}
